Oscillator Sink - FM Percussion Sample Pack

Hello you!

These are samples of sounds taken from my Percussion Patch Pack for the Korg Volca FM. The sounds are sampled across 6 pitches and 4 velocities each (except for when I messed up and there are only 5 pitches in some cases. My bad.)

You can use them, totally royalty free, but if you could give me a shout-out then that's always appreciated.

If you actually have a Volca FM, you can get the patches here: http://oscillatorsink.com/ - they are super free, and there are other patches and stuff.

If you want to check out my other stuff then you can check stuff out in these places:
http://www.youtube.com/oscillatorsink
Facebook: http://facebook.com/oscillatorsink
Twitter: https://twitter.com/OscillatorSink
Instagram: https://www.instagram.com/oscillatorsink/